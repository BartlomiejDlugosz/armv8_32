from importlib.metadata import metadata
import json
import math
import numpy as np
import scipy.optimize
import matplotlib.pyplot as plt
from numpy import polynomial

# set the font for graphs
plt.rcParams.update({
    'text.usetex': True,
    'font.family': 'Computer Modern Serif',
    'font.sans-serif': ['Computer Modern Serif']})


def genxy(file, delim=','):
    # takes a .txt file as an argument (of type str).
    # x-values should be on first line, y-values on
    # the second line, separated by delim.
    arr = np.genfromtxt(file, delimiter=delim)
    if np.ndim(arr) == 1:
        return arr
    else:
        return arr[0], arr[1]


def genRxs(xs):
    high = np.max(xs)
    low = np.min(xs)
    # add 10% on either side of the highest and lowest x value,
    # and automatically determine step size
    return np.arange(1.1*low, 1.1*high, (high-low)/10)


def genAxis(file):
    with open(file, 'r') as infile:
        axis = json.load(infile)
    # dict
    return axis


def genError(file, delim=','):
    error1, error2 = genxy(file, delim)
    # matplotlib uses the value of each element as
    # the total height/width of the error bar when
    # plotting.  Therefore, if the uncertainties required are
    # +-1, value used should be +-2
    # as a result, values from the file are doubled
    # note also that the function returns a numpy array of
    # unknown dimensions. Usually it will be 1d, but may be
    # 2d if x and y errors are specified
    return 2*error1, 2*error2


def createReg(xs, ys, degree=1):
    theta = np.polyfit(xs, ys, degree)
    # theta = [m, c]
    print(theta)
    return (theta, (theta[0] * xs)+theta[1])


def NEWcreateReg(xs, ys, degree=1):
    theta = np.polynomial.polynomial.Polynomial.fit(xs, ys, degree)
    # theta = [m, c]
    print(theta)
    # return (theta, (theta[0] * xs)+theta[1])


def initalisePlot(title, xs, ys, xlabel, ylabel):
    'call before attempting addPlot'
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.xlim(-10, 350)
    plt.ylim(0, 6.2)
    # plt.errorbar(xs, ys, xerr=xerror, yerr=yerror, fmt='x')
    # plt.plot(rxs, rys, '-', label="fitted")
    plt.grid()
    plt.title(title)
    # 72 dpi is default for screens, doesn't matter much for a pdf
    # however, higher values will increase file size without much benefit


def addErrorPlot(xs, ys, xerror=None, yerror=None, colour='black'):
    plt.errorbar(xs, ys, xerr=xerror, yerr=yerror,
                 fmt='x', color=colour, linewidth=0.5, capsize=0.25)


def addRegPlot(rxs, rys, colour='black'):
    plt.plot(rxs, rys, '-', label="fitted", color=colour, linewidth=0.5)


def savePlot(title, resolution=72):
    plt.savefig(f'{title}.pdf', dpi=resolution)

# TODO: add plot from two points function?


def saveConstants(theta, file):
    print(f'Equation: y = {"%.3g" % theta[0]}x + {"%.3g" % theta[1]}')
    r_constants = {
        "m": theta[0],
        "c": theta[1],
    }
    with open(file, "w") as outfile:
        json.dump(r_constants, outfile, indent=4)
