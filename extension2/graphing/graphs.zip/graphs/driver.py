from functions import *
x, y = genxy('expo.txt')
print('create reg:')
m, ys = createReg(x, y)
print('create m:')
print(m)

# NEWcreateReg(x, ys)

initalisePlot("Decay of Voltage, $V=6.05\\mathrm{e}^{(-t/119)}$",
              x, y, '$t$ / s', "$V$ / V")

# bruhxs = np.array([-10, 350])
# bruhys = np.array([-10*m[0]+m[1], 350*m[0]+m[1]])
tauxs = np.array([-10, 119])
tauxs2 = np.array([-10, 2*119])
tauys = np.array([6.05/np.e, 6.05/np.e])
tauys2 = np.array([6.05/(np.e)**2, 6.05/(np.e)**2])
# print(bruhxs)
# print(bruhys)

horxs = np.array([119, 119])
horxs2 = np.array([2*119, 2*119])
horys = np.array([0, 6.05/np.e])
horys2 = np.array([0, 6.05/(np.e)**2])

print(tauys)
print(tauys2)

xerror = np.array([1 for _ in range(30)])

with open('lnreduced.txt') as file:
    content = np.array(file.readlines())
    yerror = np.array([abs(float(line.strip())) for line in content])
print(yerror)

expoxs = np.arange(0, 350, 1)
expoys = np.array([6.05*(np.e)**(-x/119) for x in expoxs])

# addRegPlot(bruhxs, bruhys)
addRegPlot(tauxs, tauys, colour='orange')
addRegPlot(horxs, horys, colour='orange')
addRegPlot(tauxs2, tauys2, colour='red')
addRegPlot(horxs2, horys2, colour='red')
addRegPlot(expoxs, expoys)
addErrorPlot(x, y)
plt.annotate('$V=\\frac{V_0}{\\mathrm{e}}$', xy=(
    10, 2.22+0.15), color='orange', annotation_clip=False)
plt.annotate('$V=\\frac{V_0}{\\mathrm{e}^2}$', xy=(
    10, 0.82-0.25), color='red', annotation_clip=False)
plt.annotate('$t=\\tau$', xy=(119+7, 0.2),
             color='orange', annotation_clip=False)
plt.annotate('$t=2\\tau$', xy=(
    2*119+7, 0.2), color='red', annotation_clip=False)
savePlot('expo')
saveConstants(m, 'metaData.json')


# write a for loop that runs 1000 times
